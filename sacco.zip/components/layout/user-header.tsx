import { UserButton } from "@/components/user-button"

export function UserHeader() {
  return <UserButton />
}

